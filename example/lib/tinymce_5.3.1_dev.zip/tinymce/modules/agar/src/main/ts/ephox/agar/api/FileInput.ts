import { sRunOnPatchedFileInput, cRunOnPatchedFileInput } from '../file/PatchInputFiles';

export {
  sRunOnPatchedFileInput,
  cRunOnPatchedFileInput
};
